import os
from pathlib import Path

from dotenv import load_dotenv
from google import genai
from langchain_google_genai import ChatGoogleGenerativeAI


ROOT_ENV = Path(__file__).resolve().parents[4] / ".env"
PACKAGE_ENV = Path(__file__).resolve().parents[2] / ".env"

load_dotenv(ROOT_ENV)
load_dotenv(PACKAGE_ENV, override=False)

PRO_MODEL = "models/gemini-3.1-pro-preview"
FLASH_MODEL = "models/gemini-3.5-flash"


def _api_key() -> str:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is required for Retrace AI models.")
    return api_key


def get_available_models() -> list[str]:
    client = genai.Client(api_key=_api_key())
    return [model.name for model in client.models.list()]


flash_lite = ChatGoogleGenerativeAI(
    model=FLASH_MODEL,
    temperature=0,
    google_api_key=_api_key(),
)

flash = ChatGoogleGenerativeAI(
    model=PRO_MODEL,
    temperature=0,
    google_api_key=_api_key(),
)

flash_vision = ChatGoogleGenerativeAI(
    model=FLASH_MODEL,
    temperature=0,
    google_api_key=_api_key(),
)
