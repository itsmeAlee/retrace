from pydantic import BaseModel, Field


class CheckpointSummary(BaseModel):
    title: str = Field(
        default="Untitled checkpoint",
        description="Short descriptive title for the checkpoint, 5-8 words max.",
    )
    summary: str = Field(
        default="No content was captured in this checkpoint yet.",
        description="Main second-person checkpoint summary paragraph.",
    )
    key_points: list[str] = Field(
        default_factory=list,
        description="Three to five clear takeaways worth remembering.",
    )
    sources_used: list[str] = Field(
        default_factory=list,
        description="Titles or domains of up to five processed sources.",
    )
    has_diagram: bool = False
    diagram_mermaid: str | None = None
    capture_count: int = 0
