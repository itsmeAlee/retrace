import json
import logging
from typing import Any

from appwrite.client import Client
from appwrite.exception import AppwriteException
from appwrite.query import Query
from appwrite.services.storage import Storage
from appwrite.services.tables_db import TablesDB
from langchain_core.prompts import ChatPromptTemplate

from ..models.gemini import flash_lite
from ..models.resume_card import ResumeCard

logger = logging.getLogger(__name__)


def _rows(result: Any) -> list[dict[str, Any]]:
    if isinstance(result, dict):
        return result.get("rows", [])
    return getattr(result, "rows", [])


def _decode_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, str)]
    if not isinstance(value, str) or not value.strip():
        return []
    try:
        parsed = json.loads(value)
        return [item for item in parsed if isinstance(item, str)] if isinstance(parsed, list) else []
    except json.JSONDecodeError:
        return []


def _read_details(storage: Storage, tables: TablesDB, db_id: str, details_table_id: str, details_bucket_id: str, checkpoint_id: str) -> dict[str, Any]:
    row = tables.get_row(db_id, details_table_id, checkpoint_id)
    data = storage.get_file_download(details_bucket_id, row["detailsFileId"])
    text = data.decode("utf-8") if isinstance(data, bytes) else str(data)
    return json.loads(text or "{}")


def build_resume_context(checkpoints: list[dict[str, Any]]) -> str:
    context_parts: list[str] = []
    for index, checkpoint in enumerate(checkpoints):
        details = checkpoint.get("_aiDetails", {})
        context_parts.append(
            f"""Checkpoint {index + 1}: {checkpoint.get("checkpointName") or "Untitled Checkpoint"}
Summary: {details.get("aiSummary", "")}
Key findings: {_decode_list(details.get("aiKeyFindings"))}
Suggested next: {details.get("aiSuggestedNext", "")}"""
        )
    return "\n\n".join(context_parts)


def generate_resume_card(
    session_id: str,
    session_name: str,
    appwrite_endpoint: str,
    appwrite_project_id: str,
    appwrite_api_key: str,
    db_id: str,
    capture_items_col_id: str,
    *,
    capture_details_col_id: str = "capture_details",
    capture_details_bucket_id: str = "capture-details",
    user_id: str | None = None,
) -> ResumeCard | None:
    try:
        client = (
            Client()
            .set_endpoint(appwrite_endpoint)
            .set_project(appwrite_project_id)
            .set_key(appwrite_api_key)
        )
        tables = TablesDB(client)
        storage = Storage(client)

        result = tables.list_rows(
            db_id,
            capture_items_col_id,
            [
                Query.equal("sessionId", session_id),
                Query.equal("isCheckpoint", True),
                Query.order_asc("createdAt"),
                Query.limit(100),
            ],
        )

        complete_checkpoints: list[dict[str, Any]] = []
        for checkpoint in _rows(result):
            if user_id and checkpoint.get("userId") != user_id:
                continue
            try:
                details = _read_details(
                    storage,
                    tables,
                    db_id,
                    capture_details_col_id,
                    capture_details_bucket_id,
                    checkpoint["$id"],
                )
            except AppwriteException:
                continue
            except Exception:
                logger.exception("Failed to read checkpoint AI details.")
                continue
            if details.get("aiStatus") == "complete" and details.get("aiSummary"):
                complete_checkpoints.append({**checkpoint, "_aiDetails": details})

        if not complete_checkpoints:
            return None

        context = build_resume_context(complete_checkpoints)
        last_checkpoint = complete_checkpoints[-1]
        prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    """You are generating a session resume card for a user returning to their research session.
Be warm, specific, and helpful. Write in second person. Reference actual content, not generic statements. Be concise.
The user wants to pick up quickly.""",
                ),
                (
                    "human",
                    """Session: {session_name}
Total checkpoints: {total_checkpoints}

Here are all the checkpoint summaries in order:

{full_context}

The most recent checkpoint is:
{last_checkpoint_name}

Generate a resume card that tells the user exactly where they left off and what to do next.""",
                ),
            ]
        )
        chain = prompt | flash_lite.with_structured_output(ResumeCard)
        output = chain.invoke(
            {
                "session_name": session_name,
                "total_checkpoints": len(complete_checkpoints),
                "full_context": context,
                "last_checkpoint_name": last_checkpoint.get("checkpointName") or "Untitled Checkpoint",
            }
        )
        if not isinstance(output, ResumeCard):
            output = ResumeCard.model_validate(output)
        return output.model_copy(
            update={
                "total_checkpoints": len(complete_checkpoints),
                "session_name": session_name,
                "last_checkpoint_name": last_checkpoint.get("checkpointName") or output.last_checkpoint_name,
            }
        )
    except Exception:
        logger.exception("Failed to generate resume card.")
        return None
