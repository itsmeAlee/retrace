import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI


ROOT_ENV = Path(__file__).resolve().parents[4] / ".env"
PACKAGE_ENV = Path(__file__).resolve().parents[2] / ".env"

load_dotenv(ROOT_ENV)
load_dotenv(PACKAGE_ENV, override=False)

if not os.environ.get("GOOGLE_API_KEY") and os.environ.get("GEMINI_API_KEY"):
    os.environ["GOOGLE_API_KEY"] = os.environ["GEMINI_API_KEY"]


flash_lite = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash-lite",
    temperature=0,
)

flash = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0,
)

flash_vision = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0,
)
