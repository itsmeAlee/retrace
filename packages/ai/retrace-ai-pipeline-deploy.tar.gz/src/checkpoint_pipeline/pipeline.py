from __future__ import annotations

import base64
import json
import logging
import mimetypes
import os
from io import BytesIO
from pathlib import Path
from typing import Any, TypedDict
from urllib.parse import parse_qs, urlparse

import requests
from appwrite.client import Client
from appwrite.services.storage import Storage
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import END, START, StateGraph
from pypdf import PdfReader
from youtube_transcript_api import YouTubeTranscriptApi

from src.models.checkpoint_summary import CheckpointSummary
from src.models.gemini import FLASH_MODEL, PRO_MODEL, flash, flash_vision
from src.utils.mermaid_validator import clean_mermaid, validate_mermaid

logger = logging.getLogger(__name__)


class CheckpointPipelineState(TypedDict):
    checkpoint_row_id: str
    checkpoint_name: str
    session_name: str
    note_content: str
    captures: list[dict[str, Any]]
    processed_content: str
    summary: CheckpointSummary | None
    error: str | None
    appwrite_endpoint: str
    appwrite_project_id: str
    appwrite_api_key: str
    appwrite_bucket_id: str


def source_name(capture: dict[str, Any]) -> str:
    title = capture.get("source_title") or capture.get("sourceTitle") or capture.get("file_name") or capture.get("fileName")
    if title:
        return str(title)
    url = capture.get("source_url") or capture.get("sourceUrl") or capture.get("content")
    if url:
        try:
            return urlparse(str(url)).netloc or str(url)
        except Exception:
            return str(url)
    return "Untitled source"


def get_capture_value(capture: dict[str, Any], snake_key: str, camel_key: str | None = None) -> Any:
    return capture.get(snake_key) if capture.get(snake_key) is not None else capture.get(camel_key or snake_key)


def truncate_text(text: str, max_chars: int) -> str:
    clean = " ".join(text.split()) if max_chars < 2500 else text.strip()
    return clean[:max_chars]


def fetch_jina_reader(source_url: str) -> str:
    response = requests.get(f"https://r.jina.ai/{source_url}", timeout=5)
    response.raise_for_status()
    return response.text


def parse_timestamp_to_seconds(value: Any) -> int | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.isdigit():
        return int(text)
    parts = text.split(":")
    try:
        if len(parts) == 3:
            hours, minutes, seconds = [int(float(part)) for part in parts]
            return hours * 3600 + minutes * 60 + seconds
        if len(parts) == 2:
            minutes, seconds = [int(float(part)) for part in parts]
            return minutes * 60 + seconds
    except ValueError:
        return None
    return None


def extract_youtube_id(source_url: str) -> str | None:
    try:
        parsed = urlparse(source_url)
    except Exception:
        return None
    host = parsed.netloc.replace("www.", "")
    if host in {"youtube.com", "m.youtube.com", "music.youtube.com"}:
        if parsed.path == "/watch":
            return parse_qs(parsed.query).get("v", [None])[0]
        if parsed.path.startswith("/shorts/") or parsed.path.startswith("/embed/"):
            return parsed.path.strip("/").split("/")[1]
    if host == "youtu.be":
        return parsed.path.strip("/").split("/")[0] or None
    return None


def fetch_youtube_transcript(source_url: str, timestamp: Any = None) -> str:
    video_id = extract_youtube_id(source_url)
    if not video_id:
        return "Transcript unavailable."
    transcript = YouTubeTranscriptApi().fetch(video_id)
    rows = transcript.to_raw_data()
    target = parse_timestamp_to_seconds(timestamp)
    if target is not None:
        selected = [row for row in rows if target - 120 <= float(row.get("start", 0)) <= target + 120]
    else:
        selected = [row for row in rows if float(row.get("start", 0)) <= 300]
    if not selected:
        selected = rows[:40]
    return " ".join(str(row.get("text", "")) for row in selected)


def download_appwrite_file(
    endpoint: str,
    project_id: str,
    api_key: str,
    bucket_id: str,
    file_id: str,
) -> bytes:
    client = Client().set_endpoint(endpoint).set_project(project_id).set_key(api_key)
    data = Storage(client).get_file_download(bucket_id, file_id)
    return data if isinstance(data, bytes) else bytes(data)


def describe_image_with_gemini(image_bytes: bytes, mime_type: str | None) -> str:
    mime = mime_type or "image/jpeg"
    encoded = base64.b64encode(image_bytes).decode("utf-8")
    message = HumanMessage(
        content=[
            {
                "type": "text",
                "text": "Describe this image briefly in 2-3 sentences. Focus on what is relevant to research.",
            },
            {
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{encoded}"},
            },
        ]
    )
    response = flash_vision.invoke([message])
    return str(getattr(response, "content", response))


def extract_pdf_text(file_bytes: bytes, max_pages: int = 20) -> str:
    reader = PdfReader(BytesIO(file_bytes))
    pages = []
    for page in reader.pages[:max_pages]:
        pages.append(page.extract_text() or "")
    return "\n".join(pages).strip()


def extract_docx_text(file_bytes: bytes) -> str:
    try:
        import docx2txt

        temp_path = Path(os.getenv("TMP", "/tmp")) / "retrace_checkpoint_docx_extract.docx"
        temp_path.write_bytes(file_bytes)
        try:
            return docx2txt.process(str(temp_path)) or ""
        finally:
            temp_path.unlink(missing_ok=True)
    except Exception:
        return ""


def process_capture(capture: dict[str, Any], state: CheckpointPipelineState) -> str | None:
    capture_type = str(get_capture_value(capture, "type") or "text").lower()
    content = str(get_capture_value(capture, "content") or "")
    title = source_name(capture)

    if capture_type == "text":
        return f"[Text capture]: {content}" if content.strip() else None

    if capture_type == "audio":
        return f"[User voice note]: {content}" if content.strip() else None

    if capture_type == "url":
        source_url = str(get_capture_value(capture, "source_url", "sourceUrl") or content)
        try:
            fetched = truncate_text(fetch_jina_reader(source_url), 2000)
        except Exception as exc:
            logger.info("Jina fetch failed for %s: %s", source_url, exc)
            fetched = "Content unavailable."
        return f"[Web source - {title}]: {fetched}"

    if capture_type == "video":
        source_url = str(get_capture_value(capture, "source_url", "sourceUrl") or content)
        try:
            transcript = truncate_text(fetch_youtube_transcript(source_url, get_capture_value(capture, "timestamp")), 1500)
        except Exception as exc:
            logger.info("YouTube transcript failed for %s: %s", source_url, exc)
            transcript = "Transcript unavailable."
        return f"[YouTube - {title}]: {transcript}"

    file_id = get_capture_value(capture, "file_id", "fileId")
    file_name = str(get_capture_value(capture, "file_name", "fileName") or title)
    mime_type = get_capture_value(capture, "file_mime_type", "fileMimeType")
    if capture_type == "image":
        if not file_id:
            return f"[Image description]: Image file unavailable for {file_name}."
        try:
            image_bytes = download_appwrite_file(
                state["appwrite_endpoint"],
                state["appwrite_project_id"],
                state["appwrite_api_key"],
                state["appwrite_bucket_id"],
                str(file_id),
            )
            description = describe_image_with_gemini(image_bytes, str(mime_type or "image/jpeg"))
        except Exception as exc:
            logger.info("Image description failed for %s: %s", file_id, exc)
            description = f"Image description unavailable for {file_name}."
        return f"[Image description]: {description}"

    if capture_type in {"file", "pdf"}:
        if not file_id:
            return f"[Document - {file_name}]: File unavailable."
        try:
            file_bytes = download_appwrite_file(
                state["appwrite_endpoint"],
                state["appwrite_project_id"],
                state["appwrite_api_key"],
                state["appwrite_bucket_id"],
                str(file_id),
            )
            guessed_mime = str(mime_type or mimetypes.guess_type(file_name)[0] or "")
            if "pdf" in guessed_mime or file_name.lower().endswith(".pdf") or capture_type == "pdf":
                extracted = extract_pdf_text(file_bytes)
            elif "word" in guessed_mime or file_name.lower().endswith(".docx"):
                extracted = extract_docx_text(file_bytes)
            else:
                extracted = file_bytes.decode("utf-8", errors="ignore")
            extracted = truncate_text(extracted or "No extractable text found.", 3000)
        except Exception as exc:
            logger.info("File extraction failed for %s: %s", file_id, exc)
            extracted = "File content unavailable."
        return f"[Document - {file_name}]: {extracted}"

    return f"[{capture_type} capture - {title}]: {content}" if content.strip() else None


def content_processor(state: CheckpointPipelineState) -> dict[str, Any]:
    parts: list[str] = []
    note_content = state.get("note_content", "").strip()
    if note_content:
        parts.append(f"[User notes]: {note_content}")

    for i, capture in enumerate(state.get("captures", [])):
        try:
            processed = process_capture(capture, state)
            if processed:
                parts.append(processed)
        except Exception as exc:
            capture_type = capture.get("type", "unknown")
            capture_id = capture.get("id", f"index-{i}")
            logger.warning("Failed to process capture %s (type=%s): %s", capture_id, capture_type, exc)
            parts.append(f"[{capture_type} capture]: Content could not be processed.")

    return {"processed_content": "\n\n---\n\n".join(parts) if parts else "No content captured."}


def summarizer(state: CheckpointPipelineState) -> dict[str, Any]:
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are summarizing a research checkpoint for a student or knowledge worker. "
                "They captured notes, sources, and references during a focused work session. "
                "Your summary should feel like a smart research assistant reading back what they found. "
                "Be clear, specific, and moderately detailed. Reference actual content, not generic statements. "
                "Write in second person. Keep it professional but warm.",
            ),
            (
                "human",
                "Checkpoint name: {checkpoint_name}\n\n"
                "Session name: {session_name}\n\n"
                "Content captured in this checkpoint:\n{processed_content}\n\n"
                "Summarize this checkpoint. Be moderate, not too short and not overwhelming. "
                "Focus on what matters most. Set capture_count to {capture_count}.",
            ),
        ]
    )
    try:
        chain = prompt | flash.with_structured_output(CheckpointSummary)
        result = chain.invoke(
            {
                "checkpoint_name": state["checkpoint_name"],
                "session_name": state["session_name"],
                "processed_content": state["processed_content"],
                "capture_count": len(state.get("captures", [])),
            }
        )
        result.capture_count = len(state.get("captures", []))
        if not result.sources_used:
            result.sources_used = [source_name(capture) for capture in state.get("captures", []) if source_name(capture)][:5]
        return {"summary": result, "error": None}
    except Exception as exc:
        logger.exception("Checkpoint summarizer failed")
        return {"summary": None, "error": str(exc)}


def route_after_summary(state: CheckpointPipelineState) -> str:
    summary = state.get("summary")
    return "diagram_generator" if summary and summary.has_diagram else END


def diagram_generator(state: CheckpointPipelineState) -> dict[str, Any]:
    summary = state.get("summary")
    if not summary or not summary.has_diagram:
        return {}

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "Generate ONLY valid Mermaid syntax. No markdown fences, no prose. Use graph TD or flowchart LR only.",
            ),
            (
                "human",
                "Create a simple Mermaid concept map or flowchart for this checkpoint.\n"
                "Title: {title}\n"
                "Key points: {key_points}\n"
                "Maximum 8 nodes. Keep labels short.",
            ),
        ]
    )
    chain = prompt | flash | StrOutputParser()

    previous = ""
    last_error = ""
    for attempt in range(2):
        try:
            raw = chain.invoke({"title": summary.title, "key_points": "\n".join(summary.key_points), "previous": previous})
            cleaned = clean_mermaid(raw)
            valid, message = validate_mermaid(cleaned)
            if valid:
                summary.diagram_mermaid = cleaned
                summary.has_diagram = True
                return {"summary": summary}
            previous = raw
            last_error = message
        except Exception as exc:
            previous = str(exc)
            last_error = str(exc)

    summary.has_diagram = False
    summary.diagram_mermaid = None
    return {"summary": summary, "error": f"Diagram generation failed: {last_error}"}


graph = StateGraph(CheckpointPipelineState)
graph.add_node("content_processor", content_processor)
graph.add_node("summarizer", summarizer)
graph.add_node("diagram_generator", diagram_generator)
graph.add_edge(START, "content_processor")
graph.add_edge("content_processor", "summarizer")
graph.add_conditional_edges("summarizer", route_after_summary, {"diagram_generator": "diagram_generator", END: END})
graph.add_edge("diagram_generator", END)
checkpoint_graph = graph.compile()


def run_checkpoint_pipeline(
    checkpoint_id: str,
    checkpoint_name: str,
    session_name: str,
    note_content: str,
    captures: list[dict[str, Any]],
    appwrite_endpoint: str,
    appwrite_project_id: str,
    appwrite_api_key: str,
    appwrite_bucket_id: str,
) -> CheckpointSummary | None:
    try:
        result = checkpoint_graph.invoke(
            {
                "checkpoint_row_id": checkpoint_id,
                "checkpoint_name": checkpoint_name,
                "session_name": session_name,
                "note_content": note_content,
                "captures": captures,
                "processed_content": "",
                "summary": None,
                "error": None,
                "appwrite_endpoint": appwrite_endpoint,
                "appwrite_project_id": appwrite_project_id,
                "appwrite_api_key": appwrite_api_key,
                "appwrite_bucket_id": appwrite_bucket_id,
            }
        )
        return result.get("summary")
    except Exception:
        logger.exception("Checkpoint pipeline failed")
        return None
